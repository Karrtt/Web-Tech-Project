const express = require("express")
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const { stringify } = require("querystring");


app.use(bodyParser.urlencoded({extended : true}));

mongoose.connect("")

const notesSchema = {
    cityname : String,
    itemname : String,
    quantity : Integer
}

const Note = mongoose.model("Note", notesScheme);

app.get("/",function(req,res{
    res.sendFIle(_dirname + "/index.html");
}))

app.post
app.listen(3000, function (){
    console.log("server is running on 3000")
})